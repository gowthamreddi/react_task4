import './App.css';
import Usertable from './Usertable';

function App() {
  return (
    <div className="App">
      <Usertable />
    </div>
  );
}

export default App;
